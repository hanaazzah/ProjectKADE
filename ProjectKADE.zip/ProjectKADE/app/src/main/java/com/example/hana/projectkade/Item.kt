package com.example.hana.projectkade

/**
 * Created by hana on 17/11/2018.
 */

data class Item (val name: String?, val image: Int?,
                 val detail_grup: String)